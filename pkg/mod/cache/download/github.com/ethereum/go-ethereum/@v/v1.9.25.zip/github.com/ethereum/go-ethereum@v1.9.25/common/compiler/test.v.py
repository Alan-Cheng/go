@public
def test():
    hello: int128
